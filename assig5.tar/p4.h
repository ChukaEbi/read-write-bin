#define P4_H
#include <stdlib.h>
#include "etest.h"
#include <stdio.h>


void outputToText(FILE* file, Employee2 e);
void readFromFileAndPrint(FILE* file);

