#include <stdio.h>
#include <string.h>
#include "etest.h"

#define OUTFILENAME "etest.txt"

int main() {
  printf("Starting program etest.\n"); 

  // Anybody recognize these names?
  Employee harry; // Declare a local variable (a struct).
  harry.salary = 50000;
  strcpy(harry.name, "Harry Palmer"); // Copy into array in struct

  Employee bluejay; // Declare a local variable (a struct).
  bluejay.salary = 60000;
  strcpy(bluejay.name, "Erik Grantby"); // Copy into array in struct

  // Output the employees to a file.
  printf("About to write to file %s.\n", OUTFILENAME);
  FILE *outfile = fopen(OUTFILENAME, "w"); // Open or create file for writing
  outputEmployeeVerbose(outfile, &harry);
  outputEmployeeVerbose(outfile, &bluejay);
  fclose(outfile); // Close the file

  // Output the employees to stdout.
  printEmployeeVerbose(&harry);
  printEmployeeVerbose(&bluejay);

  printf("Ending program etest.\n"); 
  return 0;
}

/** Outputs one Employee structure in verbose form, to an open file stream
 * @param stream The output stream to write to (must already be open).
 * @param employee Pointer to the structure to print
*/

void outputEmployeeVerbose(FILE *stream, Employee *employee) {
  fprintf(stream, "Employee:. Name = %s, Salary = %d\n",
	  employee->name, employee->salary);
}

/** Prints one Employee structure in verbose form
 * @param employee Pointer to the structure to print
*/

void printEmployeeVerbose(Employee *employee) {
 // Save effort -- make use of other function already written!
  outputEmployeeVerbose(stdout, employee);
}

/** Fills in the fields of an Employee structure
 * @param emp Pointer to the struct. MUST ALREADY EXIST!
 * @param salary Annual salary in dollars
 * @param name Character string holding the name. Gets copied into struct.
 * @return Pointer to the same struct
 */
Employee* fillinEmployee(Employee* emp, int salary, char* name) {

}

/** Allocates an Employee struct and fills in its fields. 
 * @param salary Annual salary in dollars
 * @param name Character string holding the name. Gets copied into struct.
 * @return Pointer to the newly-allocated struct.
 */
Employee* createEmployee(int salary, char* name) {

}

